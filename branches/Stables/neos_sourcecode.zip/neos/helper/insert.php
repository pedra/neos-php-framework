<?php
/**
 * @copyright	NEOS PHP Framework - http://neosphp.org
 * @license		http://neosphp.org/license 
 * @author		Paulo R. B. Rocha - prbr@ymail.com
 * @package		Neos\Helper
 */
if(!function_exists('_insert')){
	function _insert($dados='',$table='',$dtbase=''){
		
		return call_user_func($func,$um,$dois,$dtbase);	
	}
}