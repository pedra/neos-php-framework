<?php
/**
 * @copyright	NEOS PHP Framework - http://neosphp.org
 * @license		http://neosphp.org/license 
 * @author		Paulo R. B. Rocha - prbr@ymail.com
 * @package		Neos\Helper
 * @subpackage	NeosTags
 */ 
  
if(!function_exists('_neostag_script')){
	
	function _neostag_script($ret){
		//trigger_error('Esta função ainda não foi definida');
	}
	
}