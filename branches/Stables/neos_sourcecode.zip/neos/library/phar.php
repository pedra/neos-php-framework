<?php

	/** Manipulação de arquivos PHAR
	 * 	Criação, modificação, carregamento de arquivos PHAR
	 */
	class Phar extends NEOS {
		
		function __construct($file) {
			$this->file = $file;
			
		}
	}
	

