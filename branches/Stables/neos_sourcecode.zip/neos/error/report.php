<?php
$etype[0] = 'Erro indeterminado!';
$etype['neos/doc/type/1'] = 'View não encontrada!';




$etype['neos/db/driver/mysql/1'] = 'Não foi possível conectar ao banco de dados';
$etype['neos/db/driver/mysql/2'] = 'Error in prepare';
$etype['neos/db/driver/mysql/3'] = 'Bind sem Prepare!?';
$etype['neos/db/driver/mysql/4'] = 'Executar oque?!';
$etype['neos/db/driver/mysql/5'] = 'Query sem argumentos!';
$etype['neos/db/driver/mysql/6'] = 'Formato inválido para INSERT!';
$etype['neos/db/driver/mysql/7'] = 'Formato inválido para UPDATE!';