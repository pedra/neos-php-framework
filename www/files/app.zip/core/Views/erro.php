<h2>ERROR:</h2>
<p>Esta aplicação foi interrompida porque ocorreu um ERRO!</p>

<div class="msg"><?php echo utf8_encode($msg);?></div>