<h2>EXCEPTION:</h2>
<p>Esta aplicação foi interrompida porque ocorreu uma EXCEÇÃO!</p>

<div class="msg"><?php echo $msg;?></div>