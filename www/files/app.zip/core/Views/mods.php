<h2>Erro no MÓDULO!</h2>

<div class="msg"><?php echo $msg;?></div>

<h2>Solução:</h2>
<div class="dica">

<ol>
<li>Verifique se foi informado o nome correto do módulo.</li>
<li>Baixe o módulo do site do NEOS.</li>
<li>Crie o seu próprio módulo seguindo as informações do manual do NEOS.</li>
</ol>

</div>