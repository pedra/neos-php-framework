<?php
/*	USER OBJECT
	Esta classe implementa um objeto USER que contem as definições do usuário do site/aplicação corrente.
	Para a preservação dos dados entre sessões se fáz necessário o uso de um banco de dados escolhido pelo desenvolvedor ou um bd em Sqlite.
	As configurações para o USER estão no arquivo '...core/Config/user.php'.
	Os seguintes parâmetros podem ser configurados: identificação, autenticação, permissão, rastro (logs), ciclo vital, categoria, bagagens, etc.
	
	TODO: construir...
*/
class NEOS_USER {
	
	function __construct(){}	
	
	function add(){}
	
}