<?php
if(!function_exists('_insert')){
	function _insert($dados='',$table='',$dtbase=''){
		
		return call_user_func($func,$um,$dois,$dtbase);	
	}
}