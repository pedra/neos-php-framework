<?php
/*
NEOS PHP Framework
	Todos os direitos reservados - proibida a utilização deste material sem prévia autorização.
	Paulo R. B. Rocha - prbr@ymail.com
	http://neophp.tk
*/

class Site  extends NEOS_models{
		
	function getCidade()
	{
		$db = _db('SELECT ID,CIDADE FROM CIDADES');		
		foreach ( $db as $row ){$dt [ $row->ID ] = $row->CIDADE;}		
		return  $dt;		
	}
	
	function getEstado()
	{
		$db = _db('SELECT SIGLA,ESTADO FROM ESTADOS');		
		foreach ( $db as $row ){$dt [ $row->SIGLA ] = $row->ESTADO;}		
		return  $dt;		
	}
	
	function putCadastro($dados)
	{
		_db('clientes',$dados,'','insert');	
	}
	
	function putContato($dados)
	{
		_db('contato',$dados,'','insert');	
	}
	
}
