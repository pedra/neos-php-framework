<?php 
/*
NEOS PHP Framework
	Todos os direitos reservados - proibida a utilização deste material sem prévia autorização.
	Paulo R. B. Rocha - prbr@ymail.com
	http://neophp.tk
*/
	
class Inicial extends  NEOS {
		
	function index()
	{
		$this->_view('inicial');
	}	
}
