<?php
/*
NEOS PHP Framework
	Todos os direitos reservados - proibida a utilização deste material sem prévia autorização.
	Paulo R. B. Rocha - prbr@ymail.com
	http://neophp.tk
*/
	
class Cadastro extends  NEOS {
		
	function index()
	{
		//selecionando o MODEL
		$model = $this->_model('site');
		
		//variavel para a VIEW
		$this->_viewVar('cidade',$model->getCidade());
		
		//chamado a VIEW
		$this->_view('cadastro');		
	}
	
	function cadastrar()
	{
		$dados = $this->_escape($_POST);
		
		//selecionando o MODEL
		$model = $this->_model('site');	
		
		$model->putCadastro($dados);
		
		//chamado a VIEW
		$this->_view('ok');
	}
}
