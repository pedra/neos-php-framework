<?php
/*
NEOS PHP Framework
	Todos os direitos reservados - proibida a utilização deste material sem prévia autorização.
	Paulo R. B. Rocha - prbr@ymail.com
	http://neophp.tk
*/
	
class Contato extends  NEOS {
		
	function index()
	{	
		//selecionando o MODEL
		$model = $this->_model('site');
		
		//variavel para a VIEW
		$this->_viewVar('estado',$model->getEstado());
		
		//chamado a VIEW
		$this->_view('contato');		
	}	
	
	function enviar_contato()
	{		
		$dados = $this->_escape($_POST);
		
		//selecionando o MODEL
		$model = $this->_model('site');	
		
		$model->putContato($dados);
		
		//chamado a VIEW
		$this->_view('ok');
	}
}
