<?php
$cfg->static_view=true;

//Banco de Dados
$cfg->default->db='mysql';

$cfg->db->mysql->driver='mysql';
$cfg->db->mysql->host='localhost';
$cfg->db->mysql->user='neos';
$cfg->db->mysql->pass='123456';
$cfg->db->mysql->database='site';