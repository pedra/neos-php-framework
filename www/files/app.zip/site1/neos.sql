SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

CREATE TABLE cidades (
  ID int(10) unsigned NOT NULL AUTO_INCREMENT,
  CIDADE varchar(200) DEFAULT NULL,
  ESTADO char(2) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(1, 'Mag�', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(2, 'Duque de Caxias', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(3, 'Petr�polis', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(4, 'Teres�polis', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(5, 'Niter�i', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(6, 'S�o Gon�alo', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(7, 'Campo Grande', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(8, 'Itabora�', 'RJ');
INSERT INTO cidades (ID, CIDADE, ESTADO) VALUES(9, 'Guapimirim', 'RJ');

CREATE TABLE clientes (
  ID int(10) unsigned NOT NULL AUTO_INCREMENT,
  NOME varchar(100) DEFAULT NULL,
  EMAIL varchar(100) DEFAULT NULL,
  SENHA varchar(100) DEFAULT NULL,
  RUA varchar(200) DEFAULT NULL,
  NUMERO varchar(20) DEFAULT NULL,
  COMPLEMENTO text,
  BAIRRO varchar(200) DEFAULT NULL,
  CIDADE int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

CREATE TABLE contato (
  ID int(10) unsigned NOT NULL AUTO_INCREMENT,
  NOME varchar(100) DEFAULT NULL,
  EMAIL varchar(100) DEFAULT NULL,
  RUA varchar(200) DEFAULT NULL,
  NUMERO varchar(20) DEFAULT NULL,
  BAIRRO varchar(200) DEFAULT NULL,
  CIDADE varchar(200) DEFAULT NULL,
  ESTADO char(2) DEFAULT NULL,
  MSG text,
  NEWSLETTER varchar(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

CREATE TABLE estados (
  SIGLA char(2) NOT NULL,
  ESTADO varchar(20) DEFAULT NULL,
  PRIMARY KEY (SIGLA)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO estados (SIGLA, ESTADO) VALUES('AL', 'Alagoas');
INSERT INTO estados (SIGLA, ESTADO) VALUES('AC', 'Acre');
INSERT INTO estados (SIGLA, ESTADO) VALUES('AM', 'Amazonas');
INSERT INTO estados (SIGLA, ESTADO) VALUES('AP', 'Amapa');
INSERT INTO estados (SIGLA, ESTADO) VALUES('BA', 'Bahia');
INSERT INTO estados (SIGLA, ESTADO) VALUES('CE', 'Cear�');
INSERT INTO estados (SIGLA, ESTADO) VALUES('DF', 'Distrito Federal');
INSERT INTO estados (SIGLA, ESTADO) VALUES('ES', 'Esp�rito Santo');
INSERT INTO estados (SIGLA, ESTADO) VALUES('GO', 'Goi�s');
INSERT INTO estados (SIGLA, ESTADO) VALUES('MA', 'Maranh�o');
INSERT INTO estados (SIGLA, ESTADO) VALUES('MG', 'Minas Gerais');
INSERT INTO estados (SIGLA, ESTADO) VALUES('MS', 'Mato Grosso do Sul');
INSERT INTO estados (SIGLA, ESTADO) VALUES('MT', 'Mato Grosso');
INSERT INTO estados (SIGLA, ESTADO) VALUES('PA', 'Par�');
INSERT INTO estados (SIGLA, ESTADO) VALUES('PB', 'Para�ba');
INSERT INTO estados (SIGLA, ESTADO) VALUES('PE', 'Pernambuco');
INSERT INTO estados (SIGLA, ESTADO) VALUES('PI', 'Piau�');
INSERT INTO estados (SIGLA, ESTADO) VALUES('PR', 'Paran�');
INSERT INTO estados (SIGLA, ESTADO) VALUES('RJ', 'Rio de Janeiro');
INSERT INTO estados (SIGLA, ESTADO) VALUES('RN', 'Rio Grande do Norte');
INSERT INTO estados (SIGLA, ESTADO) VALUES('RO', 'Rond�nia');
INSERT INTO estados (SIGLA, ESTADO) VALUES('RR', 'Roraima');
INSERT INTO estados (SIGLA, ESTADO) VALUES('RS', 'Rio Grande do Sul');
INSERT INTO estados (SIGLA, ESTADO) VALUES('SC', 'Santa Catarina');
INSERT INTO estados (SIGLA, ESTADO) VALUES('SE', 'Sergipe');
INSERT INTO estados (SIGLA, ESTADO) VALUES('SP', 'S�o Paulo');
INSERT INTO estados (SIGLA, ESTADO) VALUES('TO', 'Tocantins');