<?php 
@$cfg->app='app';
include '../core/core.php';

//Opcionalmente use o CORE em PHAR: include 'phar://app/core.neos/core.php';
//Somente se sua versão do PHP for 5.2.6 (+ extensão 'php_phar') ou 5.3 em diante.