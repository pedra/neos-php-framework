<h2>Trace:</h2>
<div class="trace">
<table width="100%" border="0" cellspacing="3" cellpadding="3">
	<thead>
		<td align="center">#</td>
		<td>Class</td>
		<td align="center">Tp</td>
		<td>Function</td>
		<td>File</td>
		<td>Line</td>
	</thead>
<?php echo $content;?>
</table>
</div>

<div class="att">
<p>Desative o 'TRACE' se a sua aplicação estiver em produção!</p>
<p>Configure este display:</p>
<ol>
	<li>Para a exibição de uma mensagem personalizada,</li>
	<li>Para sua própria  classe de tratamento de erros ou</li>
	<li>Crie uma rota para o redirecionamento do usuário de sua aplicação.</li>
</ol>
<p>Para mais detalhes veja o manual do NEOS.</p>
</div>


</body>
</html>